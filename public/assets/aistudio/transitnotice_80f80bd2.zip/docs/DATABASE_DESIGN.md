# Database Design & Schema Specification

TransitNotice uses a normalized relational architecture implemented in SQLite with Write-Ahead Logging (WAL) and foreign key constraints enabled.

## 1. Entity-Relationship Architecture

```
[ agencies ] 1 -----< M [ sources ] 1 -----< M [ notices ] 1 -----< M [ notice_routes ]
                                                      |
                                                      +-----< M [ notice_revisions ]
                                                      |
                                                      +-----< M [ notifications ] >----- 1 [ subscribers ]
                                                                                                |
                                                                                                +--< M [ subscriber_filters ]

[ sources ] 1 -----< M [ scrape_runs ] 1 -----< M [ scrape_logs ]
[ application_settings ] (Key-Value configuration)
```

## 2. Table Schemas

### `agencies`
- `id` (VARCHAR PK): Primary identifier (e.g. `TFL`, `BART`, `MBTA`, `CTA`)
- `name` (VARCHAR NOT NULL): Official authority name
- `jurisdiction` (VARCHAR NOT NULL): Geographic region
- `website` (VARCHAR NOT NULL): Official website URL
- `contact_email` (VARCHAR): Public inquiry or open-data contact
- `created_at` (TIMESTAMP NOT NULL)

### `sources`
- `id` (VARCHAR PK): e.g. `SRC-TFL-API`
- `agency_id` (VARCHAR FK -> agencies.id)
- `name` (VARCHAR NOT NULL)
- `source_url` (VARCHAR NOT NULL)
- `source_type` (VARCHAR): `API`, `RSS`, or `HTML`
- `permission_status` (VARCHAR): `Approved`, `Conditional`, `Unverified`
- `robots_txt_status` (VARCHAR): `Allowed`, `Restricted`, `Review Needed`
- `terms_of_use_status` (VARCHAR): Open Data Licence details
- `refresh_frequency_minutes` (INTEGER DEFAULT 15)
- `is_active` (INTEGER DEFAULT 1)
- `last_attempted_at` (TIMESTAMP)
- `last_successful_fetch_at` (TIMESTAMP)
- `last_error` (TEXT)
- `consecutive_failures` (INTEGER DEFAULT 0)
- `health_status` (VARCHAR): `HEALTHY`, `DEGRADED`, `FAILING`

### `notices`
- `notice_id` (VARCHAR PK): Canonical ID
- `agency` (VARCHAR NOT NULL)
- `route_id` (VARCHAR NOT NULL): Summary representation of affected routes
- `area` (VARCHAR NOT NULL)
- `source_url` (VARCHAR NOT NULL)
- `type` (VARCHAR NOT NULL): Standardized category
- `is_type_inferred` (INTEGER DEFAULT 0)
- `title` (VARCHAR NOT NULL)
- `summary` (TEXT NOT NULL)
- `description` (TEXT NOT NULL)
- `published_at` (TIMESTAMP NOT NULL)
- `valid_from` (TIMESTAMP NOT NULL)
- `valid_to` (TIMESTAMP): Nullable for open-ended notices
- `status` (VARCHAR NOT NULL): `Active`, `Scheduled`, `Expired`, `Cancelled`, `Withdrawn`
- `observed_at` (TIMESTAMP NOT NULL)
- `last_confirmed_at` (TIMESTAMP NOT NULL)
- `last_verified_at` (TIMESTAMP NOT NULL)
- `content_hash` (VARCHAR(64) NOT NULL): SHA-256 hash
- `revision_id` (INTEGER DEFAULT 1)
- `change_summary` (TEXT)
- `source_id` (VARCHAR FK -> sources.id)
- `subscriber_filter` (VARCHAR)
- `alert_status` (VARCHAR DEFAULT 'SENT')
- `alerted_at` (TIMESTAMP)
- `is_demo` (INTEGER DEFAULT 0)

### `notice_routes` (Multi-Route Junction Table)
- `id` (INTEGER PK AUTOINCREMENT)
- `notice_id` (VARCHAR NOT NULL FK -> notices.notice_id ON DELETE CASCADE)
- `route_id` (VARCHAR NOT NULL INDEX)
- `route_name` (VARCHAR NOT NULL)
- `route_mode` (VARCHAR DEFAULT 'BUS')
- `direction` (VARCHAR)
- `UNIQUE(notice_id, route_id)`

### `notice_revisions` (Historical Audit Trail)
- `id` (INTEGER PK AUTOINCREMENT)
- `notice_id` (VARCHAR NOT NULL FK -> notices.notice_id ON DELETE CASCADE)
- `revision_id` (INTEGER NOT NULL)
- `title`, `summary`, `description`, `type`, `status`
- `valid_from`, `valid_to`
- `content_hash` (VARCHAR)
- `change_type` (`NEW`, `REVISED`, `EXTENDED`, `WITHDRAWN`, `CANCELLED`, `EXPIRED`)
- `change_summary` (TEXT NOT NULL)
- `detected_at` (TIMESTAMP NOT NULL)
- `affected_routes_json` (TEXT NOT NULL)

### `notifications`
- `id` (VARCHAR PK)
- `notice_id` (VARCHAR FK -> notices.notice_id)
- `subscriber_id` (VARCHAR FK -> subscribers.id)
- `channel` (`IN_APP`, `DEMO_EMAIL`)
- `event_type` (`NEW_ADVISORY`, `EXTENDED_ADVISORY`, etc.)
- `title`, `message`
- `delivery_status` (`DELIVERED`, `PENDING`)
- `timestamp` (TIMESTAMP)
- `is_read` (INTEGER DEFAULT 0)
- `dedup_key` (VARCHAR UNIQUE): Enforces deduplication
