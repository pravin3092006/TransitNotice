# TransitNotice: Project Overview (WEB-07)

## 1. Problem Statement
Public transit passengers routinely face unexpected delays, detours, and planned service interruptions. Official transit advisories are scattered across disparate websites, APIs, and RSS feeds in varying formats. When authorities revise advisory timelines—such as extending a 2-day outage into a 4-day closure—passengers rarely receive clear diffs of what changed. Furthermore, stale advisories often remain visible without explicit freshness indications.

TransitNotice bridges this gap by providing an automated, ethical scraping pipeline and change-detection engine that continuously monitors authorized transit sources, tracks revision histories, extracts affected routes (including complex multi-line corridors), and displays verifiable provenance.

---

## 2. Key Objectives & Success Metrics
- **Continuous Monitoring**: Scheduled polling of TfL, BART, MBTA, and CTA.
- **Automated Change Detection**: SHA-256 hash comparison identifying new, unchanged, revised, extended, and cancelled notices.
- **Relational Integrity**: SQLite relational schema with dedicated tables for notices, multi-route associations, revision histories, and logs.
- **Zero Pill / Anti-AI-Slop Clean Design**: Professional Navy Blue (`#071B2D`) and Cyan (`#13BCEB`) UI with accessible contrast, responsive sidebar, and interactive charts.
- **Mentor Viva Readiness**: Live workbench to simulate challenges and evaluate acceptance tests.

---

## 3. Realistic Stakeholder Personas
1. **Persona 1 — Maya Lin (Daily Commuter)**:
   - Needs: Filter by route `Route-73` or `Central Line`, check service validity windows, receive deduplicated in-app alerts for their commute corridor.
2. **Persona 2 — Alex Vance (Transit Operations Controller)**:
   - Needs: Monitor source latency, inspect robots.txt compliance, review revision history diffs when contractors extend roadworks, and execute diagnostic SQL queries.
