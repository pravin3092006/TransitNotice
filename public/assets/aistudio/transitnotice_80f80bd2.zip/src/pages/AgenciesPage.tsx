import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { Agency, Source } from '../types';
import {
  Building2,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  Layers,
  FileCode2,
  Info
} from 'lucide-react';

export const AgenciesPage: React.FC = () => {
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'sources' | 'approval_doc'>('sources');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [agRes, srcRes] = await Promise.all([api.getAgencies(), api.getSources()]);
      setAgencies(agRes.agencies);
      setSources(srcRes.sources);
    } catch (err) {
      console.error('Failed to load agencies/sources:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#071B2D] tracking-tight">
            Agencies & Source Provenance
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Monitored public authorities, official feed licenses, robots.txt compliance, and source health.
          </p>
        </div>

        <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-1 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('sources')}
            className={`rounded px-3 py-1.5 transition ${activeTab === 'sources' ? 'bg-white text-[#071B2D] shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
          >
            Configured Sources ({sources.length})
          </button>
          <button
            onClick={() => setActiveTab('approval_doc')}
            className={`rounded px-3 py-1.5 transition ${activeTab === 'approval_doc' ? 'bg-white text-[#071B2D] shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}
          >
            Source Approval Document
          </button>
        </div>
      </div>

      {activeTab === 'sources' ? (
        <div className="space-y-6">
          {/* Agencies Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {agencies.map((agency) => (
              <div key={agency.id} className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="rounded bg-[#071B2D] text-white px-2 py-0.5 text-xs font-bold">
                    {agency.id}
                  </span>
                  <a
                    href={agency.website}
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-400 hover:text-[#13BCEB]"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </div>
                <h3 className="font-bold text-sm text-slate-900 line-clamp-1">{agency.name}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{agency.jurisdiction}</p>
                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Contact: {agency.contact_email || 'Public Open Data'}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Sources Detailed Table */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Authorized Public Source Feeds
              </h3>
              <p className="text-xs text-slate-500">
                Ethical scraping compliance: All sources verified against robots.txt and official Open Data terms.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-3">Source Name & Agency</th>
                    <th className="py-3 px-3">Type</th>
                    <th className="py-3 px-3">Permission Status</th>
                    <th className="py-3 px-3">robots.txt Review</th>
                    <th className="py-3 px-3">Terms of Use</th>
                    <th className="py-3 px-3">Frequency</th>
                    <th className="py-3 px-3">Health Status</th>
                    <th className="py-3 px-3">Last Successful Fetch</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sources.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{s.name}</div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-slate-400 font-mono text-[10px]">
                          <span>{s.agency_id}</span>
                          <span>•</span>
                          <a
                            href={s.source_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#13BCEB] hover:underline flex items-center gap-0.5"
                          >
                            <span className="truncate max-w-[180px]">{s.source_url}</span>
                            <ExternalLink className="h-2.5 w-2.5" />
                          </a>
                        </div>
                      </td>

                      <td className="py-3 px-3">
                        <span className="rounded bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-semibold text-slate-800">
                          {s.source_type}
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 border border-emerald-200">
                          {s.permission_status}
                        </span>
                      </td>

                      <td className="py-3 px-3">
                        <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-700">
                          {s.robots_txt_status}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-slate-600 max-w-[200px] truncate" title={s.terms_of_use_status}>
                        {s.terms_of_use_status}
                      </td>

                      <td className="py-3 px-3 text-slate-600 font-medium">
                        Every {s.refresh_frequency_minutes} min
                      </td>

                      <td className="py-3 px-3">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                          s.health_status === 'HEALTHY'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {s.health_status}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-slate-500 whitespace-nowrap">
                        {s.last_successful_fetch_at
                          ? new Date(s.last_successful_fetch_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                          : 'Pending'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Source Approval Document Tab (Mandatory requirement from Section 5 & PDF Task 01) */
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-xs space-y-6">
          <div className="border-b border-slate-200 pb-4">
            <span className="text-xs font-mono font-bold text-[#13BCEB] uppercase tracking-wider">
              Document: SOURCE_APPROVAL.md
            </span>
            <h2 className="text-xl font-bold text-slate-900 mt-1">
              Official Transport Source Approval & Permissions Charter
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Strict ethical guidelines, robots.txt review, rate limits, and risk mitigation strategies.
            </p>
          </div>

          <div className="space-y-6 text-xs text-slate-700 leading-relaxed">
            <div className="rounded-xl bg-slate-50 p-4 border border-slate-200">
              <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                Ethical Web Scraping Constitution
              </h4>
              <p>
                In accordance with Cybernaut internship guidelines, TransitNotice monitors ONLY publicly available authority feeds and permitted open data endpoints. We strictly uphold:
              </p>
              <ul className="list-disc pl-5 mt-2 space-y-1 text-slate-600">
                <li><strong>No Login Bypasses:</strong> Never bypass access restrictions or authentication walls.</li>
                <li><strong>No CAPTCHA Evasion:</strong> We do not deploy CAPTCHA solvers or evasive user-agent rotating proxies.</li>
                <li><strong>No Private Data:</strong> We extract solely route disruption bulletins; no passenger personal data is collected or stored.</li>
                <li><strong>Rate Limiting & Backoff:</strong> Requests are throttled with exponential backoff and a 300-second retry ceiling.</li>
              </ul>
            </div>

            {/* Matrix of Sources */}
            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 text-sm">
                Source Review Matrix
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-lg border border-slate-200 p-4 space-y-2">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>1. Transport for London (TfL)</span>
                    <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10px]">Approved</span>
                  </div>
                  <p><strong>Endpoint:</strong> api.tfl.gov.uk/Line/Mode/tube,bus,overground,dlr/Disruption</p>
                  <p><strong>License:</strong> UK Open Government Licence (OGL) v3.0 / TfL Open Data Agreement.</p>
                  <p><strong>robots.txt:</strong> Allowed. API endpoint intended for public integration.</p>
                  <p><strong>Extracted Fields:</strong> Category, description, closureText, affectedRoutes, fromDate, toDate.</p>
                  <p><strong>Risk & Mitigation:</strong> High frequency could hit rate limits; mitigated by caching and 15-minute polling.</p>
                </div>

                <div className="rounded-lg border border-slate-200 p-4 space-y-2">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>2. Bay Area Rapid Transit (BART)</span>
                    <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10px]">Approved</span>
                  </div>
                  <p><strong>Endpoint:</strong> api.bart.gov/api/bsa.aspx?cmd=bsa&json=y</p>
                  <p><strong>License:</strong> BART Developer License Agreement (Open Public Access).</p>
                  <p><strong>robots.txt:</strong> Allowed.</p>
                  <p><strong>Extracted Fields:</strong> Posted timestamp, description, affected station/lines, expires timestamp.</p>
                  <p><strong>Risk & Mitigation:</strong> Unannounced format changes; mitigated by schema validation and fallback fixtures.</p>
                </div>

                <div className="rounded-lg border border-slate-200 p-4 space-y-2">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>3. Massachusetts Bay Transportation Authority (MBTA)</span>
                    <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10px]">Approved</span>
                  </div>
                  <p><strong>Endpoint:</strong> api-v3.mbta.com/alerts</p>
                  <p><strong>License:</strong> MassDOT / MBTA Open Data Policy.</p>
                  <p><strong>robots.txt:</strong> Allowed.</p>
                  <p><strong>Extracted Fields:</strong> Header, description, active_period start/end, informed_entity route IDs.</p>
                  <p><strong>Risk & Mitigation:</strong> Large payload; filtered by activity=BOARD,EXIT,RIDE to reduce bandwidth.</p>
                </div>

                <div className="rounded-lg border border-slate-200 p-4 space-y-2">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>4. Chicago Transit Authority (CTA)</span>
                    <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10px]">Approved</span>
                  </div>
                  <p><strong>Endpoint:</strong> transitchicago.com/alerts/rss.aspx</p>
                  <p><strong>License:</strong> CTA Terms of Website Use (Public RSS syndication).</p>
                  <p><strong>robots.txt:</strong> Allowed for RSS syndication.</p>
                  <p><strong>Extracted Fields:</strong> Title, description, pubDate, line tags.</p>
                  <p><strong>Risk & Mitigation:</strong> XML/HTML malformed markup; parsed with safe exception handlers.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
