import React, { useState } from 'react';
import {
  Bus,
  Search,
  ShieldCheck,
  RefreshCw,
  Bell,
  ArrowRight,
  Clock,
  MapPin,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Layers,
  FileCheck2
} from 'lucide-react';
import { DashboardStats, TransitNotice } from '../types';
import { NoticeCard } from '../components/NoticeCard';

interface HomePageProps {
  stats: DashboardStats | null;
  recentNotices: TransitNotice[];
  onSearch: (query: string) => void;
  onSelectNotice: (notice: TransitNotice) => void;
  onNavigateTab: (tab: string) => void;
  onFilterRoute: (routeId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  stats,
  recentNotices,
  onSearch,
  onSelectNotice,
  onNavigateTab,
  onFilterRoute
}) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
      onNavigateTab('notices');
    }
  };

  const quickRoutes = ['Route-73', 'Central', 'Yellow', 'Red-Line', 'Blue-Line', 'Route-390'];

  return (
    <div className="space-y-10 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#071B2D] via-[#0B2A46] to-[#071B2D] text-white p-8 sm:p-12 shadow-xl border border-slate-800">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-cyan-950/70 border border-[#13BCEB]/30 px-3 py-1 text-xs font-semibold text-cyan-300 mb-6">
            <span className="h-2 w-2 rounded-full bg-[#13BCEB] animate-ping" />
            Official Public Transport Service Update Tracker • WEB-07
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Accurate, real-time public transit advisory monitoring.
          </h1>

          <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
            Never be caught off-guard by route diversions or planned closures. TransitNotice collects official advisories from verified authorities, tracks revision diffs, and computes active validity windows.
          </p>

          {/* Search Box */}
          <form onSubmit={handleSearchSubmit} className="mt-8 flex flex-col sm:flex-row gap-2 max-w-xl">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
              <input
                type="text"
                placeholder="Search by route, line, or area (e.g., Route 73, Oxford Circus)..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full rounded-xl bg-white/10 border border-white/20 px-4 py-3 pl-11 text-sm text-white placeholder-slate-400 backdrop-blur-md focus:bg-white/15 focus:border-[#13BCEB] focus:outline-none focus:ring-2 focus:ring-[#13BCEB]/50 transition"
              />
            </div>
            <button
              type="submit"
              className="rounded-xl bg-[#13BCEB] px-6 py-3 text-sm font-bold text-slate-950 hover:bg-cyan-300 transition shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
            >
              <span>Search Notices</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>

          {/* Quick Route Pills */}
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <span>Popular Routes:</span>
            {quickRoutes.map((r) => (
              <button
                key={r}
                onClick={() => {
                  onFilterRoute(r);
                  onNavigateTab('notices');
                }}
                className="rounded-lg bg-white/10 px-2.5 py-1 text-xs font-medium text-slate-200 hover:bg-[#13BCEB] hover:text-slate-950 transition border border-white/10"
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Live System Status Cards */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigateTab('notices')}
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-[#13BCEB] hover:shadow-md cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Active Advisories</span>
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {stats ? stats.activeAdvisories : '...'}
          </div>
          <p className="mt-1 text-xs text-slate-500">Currently impacting travel</p>
        </div>

        <div
          onClick={() => onNavigateTab('notices')}
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-[#13BCEB] hover:shadow-md cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Route Diversions</span>
            <span className="h-2.5 w-2.5 rounded-full bg-amber-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {stats ? stats.routeDiversions : '...'}
          </div>
          <p className="mt-1 text-xs text-slate-500">Detours & rerouted lines</p>
        </div>

        <div
          onClick={() => onNavigateTab('history')}
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-[#13BCEB] hover:shadow-md cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Revised / Extended</span>
            <span className="h-2.5 w-2.5 rounded-full bg-indigo-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {stats ? stats.revisedNotices : '...'}
          </div>
          <p className="mt-1 text-xs text-slate-500">History preserved in audit trail</p>
        </div>

        <div
          onClick={() => onNavigateTab('scraper')}
          className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-[#13BCEB] hover:shadow-md cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Monitored Sources</span>
            <span className="h-2.5 w-2.5 rounded-full bg-cyan-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {stats ? stats.healthySources : '...'} / {stats ? stats.totalSources : '...'}
          </div>
          <p className="mt-1 text-xs text-slate-500">TfL, BART, MBTA, CTA</p>
        </div>
      </section>

      {/* Recently Updated Notices Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Recently Updated Advisories
            </h2>
            <p className="text-xs text-slate-500">
              Verified official notices with active change provenance
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('notices')}
            className="flex items-center gap-1 text-xs font-semibold text-[#13BCEB] hover:underline"
          >
            <span>View All Notices</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {recentNotices.slice(0, 3).map((notice) => (
            <NoticeCard
              key={notice.notice_id}
              notice={notice}
              onClick={() => onSelectNotice(notice)}
              onFilterRoute={(r) => {
                onFilterRoute(r);
                onNavigateTab('notices');
              }}
            />
          ))}
        </div>
      </section>

      {/* Architecture Highlights & Two Realistic Personas */}
      <section className="rounded-3xl border border-slate-200 bg-slate-50 p-8 space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            System Design & Stakeholder Personas
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Built according to Cybernaut WEB-07 Specifications with strict data integrity and change detection.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Persona 1 */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-100 text-cyan-700">
                <Bus className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Persona 1: Daily Passenger (Maya Lin)</h3>
                <span className="text-[11px] text-slate-400">Regular commuter in high-frequency transit corridors</span>
              </div>
            </div>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
              <li>Searches specific routes (e.g. Route 73, Central Line) before departure.</li>
              <li>Receives filtered alerts only for subscribed lines and stations.</li>
              <li>Views announced validity windows so they know exactly when closures start and conclude.</li>
            </ul>
          </div>

          {/* Persona 2 */}
          <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900">Persona 2: Operations Monitor (Alex Vance)</h3>
                <span className="text-[11px] text-slate-400">Transit controller & transport data auditor</span>
              </div>
            </div>
            <ul className="text-xs text-slate-600 space-y-1.5 list-disc pl-5">
              <li>Monitors source health, HTTP response latency, and robots.txt compliance.</li>
              <li>Inspects historical notice revision diffs (e.g. 24-hour extension events).</li>
              <li>Triggers on-demand scraper syncs and inspects failure diagnostics with retry backoffs.</li>
            </ul>
          </div>
        </div>

        {/* 6 Mandatory Acceptance Rules Preview */}
        <div className="rounded-xl border border-cyan-200 bg-cyan-50/50 p-4 text-xs text-slate-700">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-cyan-950 flex items-center gap-1.5">
              <FileCheck2 className="h-4 w-4 text-[#13BCEB]" />
              Mandatory Acceptance Tests Verified
            </span>
            <button
              onClick={() => onNavigateTab('mentor')}
              className="text-xs font-semibold text-cyan-800 hover:underline"
            >
              Open Mentor Test Console →
            </button>
          </div>
          <p className="text-[11px] text-slate-600">
            TransitNotice automatically enforces: (1) Expired notices not active; (2) Multi-route filtering; (3) Outage extension revision preservation; (4) Timezone ISO-8601 normalization; (5) Explicit last verification timestamps; (6) Source error data integrity.
          </p>
        </div>
      </section>
    </div>
  );
};
