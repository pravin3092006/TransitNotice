import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core';

// 1. Users table (stores Firebase Auth users + profiles)
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  name: text('name'),
  photoUrl: text('photo_url'),
  persona: text('persona').default('PASSENGER'), // 'PASSENGER' or 'OPERATIONS_MONITOR'
  role: text('role').default('user'), // 'user' or 'admin'
  createdAt: timestamp('created_at').defaultNow(),
});

// 2. User Subscribed Routes & Alerts
export const userSubscriptions = pgTable('user_subscriptions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  routeId: text('route_id').notNull(),
  agency: text('agency'),
  area: text('area'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 3. Agencies
export const agencies = pgTable('agencies', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  jurisdiction: text('jurisdiction').notNull(),
  website: text('website').notNull(),
  contactEmail: text('contact_email'),
  createdAt: text('created_at').notNull(),
});

// 4. Sources
export const sources = pgTable('sources', {
  id: text('id').primaryKey(),
  agencyId: text('agency_id').references(() => agencies.id, { onDelete: 'cascade' }).notNull(),
  name: text('name').notNull(),
  sourceUrl: text('source_url').notNull(),
  sourceType: text('source_type').notNull(), // 'API', 'RSS', 'HTML'
  permissionStatus: text('permission_status').notNull(), // 'Approved', 'Conditional', 'Unverified'
  robotsTxtStatus: text('robots_txt_status').notNull(),
  termsOfUseStatus: text('terms_of_use_status').notNull(),
  refreshFrequencyMinutes: integer('refresh_frequency_minutes').default(15).notNull(),
  isActive: integer('is_active').default(1).notNull(),
  lastAttemptedAt: text('last_attempted_at'),
  lastSuccessfulFetchAt: text('last_successful_fetch_at'),
  lastError: text('last_error'),
  consecutiveFailures: integer('consecutive_failures').default(0).notNull(),
  healthStatus: text('health_status').default('HEALTHY').notNull(),
  createdAt: text('created_at').notNull(),
});

// 5. Notices
export const notices = pgTable('notices', {
  noticeId: text('notice_id').primaryKey(),
  agency: text('agency').notNull(),
  routeId: text('route_id').notNull(),
  area: text('area').notNull(),
  sourceUrl: text('source_url').notNull(),
  type: text('type').notNull(),
  isTypeInferred: integer('is_type_inferred').default(0).notNull(),
  title: text('title').notNull(),
  summary: text('summary').notNull(),
  description: text('description').notNull(),
  publishedAt: text('published_at').notNull(),
  validFrom: text('valid_from').notNull(),
  validTo: text('valid_to'),
  status: text('status').notNull(), // 'Scheduled', 'Active', 'Expired', 'Cancelled', 'Withdrawn', 'Unknown'
  observedAt: text('observed_at').notNull(),
  lastConfirmedAt: text('last_confirmed_at').notNull(),
  lastVerifiedAt: text('last_verified_at').notNull(),
  contentHash: text('content_hash').notNull(),
  revisionId: integer('revision_id').default(1).notNull(),
  changeSummary: text('change_summary'),
  sourceId: text('source_id').references(() => sources.id, { onDelete: 'set null' }),
  subscriberFilter: text('subscriber_filter'),
  alertStatus: text('alert_status').default('SENT').notNull(),
  alertedAt: text('alerted_at'),
  isDemo: integer('is_demo').default(0).notNull(),
});

// 6. Notice Routes (Multi-Route Junction)
export const noticeRoutes = pgTable('notice_routes', {
  id: serial('id').primaryKey(),
  noticeId: text('notice_id').references(() => notices.noticeId, { onDelete: 'cascade' }).notNull(),
  routeId: text('route_id').notNull(),
  routeName: text('route_name').notNull(),
  routeMode: text('route_mode').default('BUS').notNull(),
  direction: text('direction'),
});

// 7. Notice Revisions (Immutable History)
export const noticeRevisions = pgTable('notice_revisions', {
  id: serial('id').primaryKey(),
  noticeId: text('notice_id').references(() => notices.noticeId, { onDelete: 'cascade' }).notNull(),
  revisionId: integer('revision_id').notNull(),
  title: text('title').notNull(),
  summary: text('summary').notNull(),
  description: text('description').notNull(),
  type: text('type').notNull(),
  status: text('status').notNull(),
  validFrom: text('valid_from').notNull(),
  validTo: text('valid_to'),
  contentHash: text('content_hash').notNull(),
  changeType: text('change_type').notNull(),
  changeSummary: text('change_summary').notNull(),
  detectedAt: text('detected_at').notNull(),
  affectedRoutesJson: text('affected_routes_json').notNull(),
});

// 8. Scrape Runs
export const scrapeRuns = pgTable('scrape_runs', {
  id: text('id').primaryKey(),
  sourceId: text('source_id').references(() => sources.id, { onDelete: 'cascade' }).notNull(),
  startedAt: text('started_at').notNull(),
  completedAt: text('completed_at'),
  status: text('status').notNull(),
  noticesObserved: integer('notices_observed').default(0).notNull(),
  noticesNew: integer('notices_new').default(0).notNull(),
  noticesUpdated: integer('notices_updated').default(0).notNull(),
  noticesUnchanged: integer('notices_unchanged').default(0).notNull(),
  errorMessage: text('error_message'),
  retryCount: integer('retry_count').default(0).notNull(),
});

// 9. Scrape Logs
export const scrapeLogs = pgTable('scrape_logs', {
  id: serial('id').primaryKey(),
  runId: text('run_id'),
  sourceId: text('source_id'),
  timestamp: text('timestamp').notNull(),
  level: text('level').notNull(),
  message: text('message').notNull(),
  detailsJson: text('details_json'),
});

// 10. Subscribers
export const subscribers = pgTable('subscribers', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  persona: text('persona').default('PASSENGER').notNull(),
  createdAt: text('created_at').notNull(),
});

// 11. Subscriber Filters
export const subscriberFilters = pgTable('subscriber_filters', {
  id: serial('id').primaryKey(),
  subscriberId: text('subscriber_id').references(() => subscribers.id, { onDelete: 'cascade' }).notNull(),
  agency: text('agency'),
  routeId: text('route_id'),
  area: text('area'),
  advisoryType: text('advisory_type'),
});

// 12. Notifications
export const notifications = pgTable('notifications', {
  id: text('id').primaryKey(),
  noticeId: text('notice_id').references(() => notices.noticeId, { onDelete: 'cascade' }).notNull(),
  subscriberId: text('subscriber_id').references(() => subscribers.id, { onDelete: 'cascade' }),
  userId: integer('user_id').references(() => users.id, { onDelete: 'cascade' }),
  channel: text('channel').default('IN_APP').notNull(),
  eventType: text('event_type').notNull(),
  title: text('title').notNull(),
  message: text('message').notNull(),
  deliveryStatus: text('delivery_status').default('DELIVERED').notNull(),
  timestamp: text('timestamp').notNull(),
  isRead: integer('is_read').default(0).notNull(),
  dedupKey: text('dedup_key').notNull().unique(),
});

// 13. Application Settings
export const applicationSettings = pgTable('application_settings', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  description: text('description'),
  updatedAt: text('updated_at').notNull(),
});

// Relationships
export const usersRelations = relations(users, ({ many }) => ({
  subscriptions: many(userSubscriptions),
  notifications: many(notifications),
}));

export const userSubscriptionsRelations = relations(userSubscriptions, ({ one }) => ({
  user: one(users, {
    fields: [userSubscriptions.userId],
    references: [users.id],
  }),
}));

export const noticesRelations = relations(notices, ({ many, one }) => ({
  routes: many(noticeRoutes),
  revisions: many(noticeRevisions),
  source: one(sources, {
    fields: [notices.sourceId],
    references: [sources.id],
  }),
}));

export const noticeRoutesRelations = relations(noticeRoutes, ({ one }) => ({
  notice: one(notices, {
    fields: [noticeRoutes.noticeId],
    references: [notices.noticeId],
  }),
}));

export const noticeRevisionsRelations = relations(noticeRevisions, ({ one }) => ({
  notice: one(notices, {
    fields: [noticeRevisions.noticeId],
    references: [notices.noticeId],
  }),
}));
