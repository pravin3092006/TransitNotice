import { pgDb } from './index.ts';
import { users, userSubscriptions } from './schema.ts';
import { eq, and } from 'drizzle-orm';

export async function getOrCreateUser(data: {
  uid: string;
  email: string;
  name?: string;
  photoUrl?: string;
  persona?: string;
}) {
  try {
    const result = await pgDb
      .insert(users)
      .values({
        uid: data.uid,
        email: data.email,
        name: data.name || data.email.split('@')[0],
        photoUrl: data.photoUrl,
        persona: data.persona || 'PASSENGER',
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: data.email,
          name: data.name || data.email.split('@')[0],
          photoUrl: data.photoUrl,
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Failed to get or create user:', error);
    throw new Error('Database operation failed while synchronizing user profile.', { cause: error });
  }
}

export async function getUserByUid(uid: string) {
  try {
    const res = await pgDb.select().from(users).where(eq(users.uid, uid));
    return res[0] || null;
  } catch (error) {
    console.error('Failed to fetch user by UID:', error);
    throw new Error('Database query failed for user profile.', { cause: error });
  }
}

export async function updateUserPersona(uid: string, persona: string) {
  try {
    const res = await pgDb
      .update(users)
      .set({ persona })
      .where(eq(users.uid, uid))
      .returning();
    return res[0] || null;
  } catch (error) {
    console.error('Failed to update user persona:', error);
    throw new Error('Database query failed updating user persona.', { cause: error });
  }
}

export async function getUserSubscriptions(userId: number) {
  try {
    return await pgDb
      .select()
      .from(userSubscriptions)
      .where(eq(userSubscriptions.userId, userId));
  } catch (error) {
    console.error('Failed to fetch user subscriptions:', error);
    throw new Error('Database query failed for user subscriptions.', { cause: error });
  }
}

export async function addUserSubscription(userId: number, routeId: string, agency?: string, area?: string) {
  try {
    const res = await pgDb
      .insert(userSubscriptions)
      .values({
        userId,
        routeId,
        agency,
        area,
      })
      .returning();
    return res[0];
  } catch (error) {
    console.error('Failed to add user subscription:', error);
    throw new Error('Database query failed adding subscription.', { cause: error });
  }
}

export async function removeUserSubscription(userId: number, subId: number) {
  try {
    await pgDb
      .delete(userSubscriptions)
      .where(and(eq(userSubscriptions.id, subId), eq(userSubscriptions.userId, userId)));
    return { success: true };
  } catch (error) {
    console.error('Failed to remove user subscription:', error);
    throw new Error('Database query failed deleting subscription.', { cause: error });
  }
}
