import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import axios from 'axios';

export interface DbUser {
  id: number;
  uid: string;
  email: string;
  name?: string;
  photoUrl?: string;
  persona: 'PASSENGER' | 'OPERATIONS_MONITOR';
  role: string;
  createdAt?: string;
}

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  dbUser: DbUser | null;
  token: string | null;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  signupWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  setPersona: (persona: 'PASSENGER' | 'OPERATIONS_MONITOR') => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [dbUser, setDbUser] = useState<DbUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Sync user with Cloud SQL backend
  const syncWithSqlDatabase = async (user: FirebaseUser, idToken: string) => {
    try {
      const res = await axios.post(
        '/api/auth/sync',
        {
          uid: user.uid,
          email: user.email,
          name: user.displayName || user.email?.split('@')[0],
          photoUrl: user.photoURL,
        },
        {
          headers: {
            Authorization: `Bearer ${idToken}`,
          },
        }
      );
      if (res.data?.user) {
        setDbUser(res.data.user);
      }
    } catch (err) {
      console.error('Failed to sync user with SQL database:', err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          const idToken = await user.getIdToken();
          setToken(idToken);
          await syncWithSqlDatabase(user, idToken);
        } catch (err) {
          console.error('Error fetching token:', err);
        }
      } else {
        setToken(null);
        setDbUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleAuthProvider);
      if (res.user) {
        const idToken = await res.user.getIdToken();
        setToken(idToken);
        await syncWithSqlDatabase(res.user, idToken);
      }
    } catch (error: any) {
      console.error('Google Sign-In failed:', error);
      throw error;
    }
  };

  const signupWithEmail = async (email: string, pass: string, name: string) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await updateProfile(res.user, { displayName: name });
        const idToken = await res.user.getIdToken();
        setToken(idToken);
        await syncWithSqlDatabase(res.user, idToken);
      }
    } catch (error: any) {
      console.error('Sign-up failed:', error);
      throw error;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        const idToken = await res.user.getIdToken();
        setToken(idToken);
        await syncWithSqlDatabase(res.user, idToken);
      }
    } catch (error: any) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
    setFirebaseUser(null);
    setDbUser(null);
    setToken(null);
  };

  const setPersona = async (persona: 'PASSENGER' | 'OPERATIONS_MONITOR') => {
    if (token) {
      try {
        const res = await axios.put(
          '/api/auth/persona',
          { persona },
          { headers: { Authorization: `Bearer ${token}` } }
        );
        if (res.data?.user) {
          setDbUser(res.data.user);
        }
      } catch (err) {
        console.error('Failed to update persona in SQL:', err);
      }
    }
  };

  const refreshProfile = async () => {
    if (token) {
      try {
        const res = await axios.get('/api/auth/me', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.data?.user) {
          setDbUser(res.data.user);
        }
      } catch (err) {
        console.error('Failed to refresh user profile:', err);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        dbUser,
        token,
        loading,
        loginWithGoogle,
        signupWithEmail,
        loginWithEmail,
        logout,
        setPersona,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
