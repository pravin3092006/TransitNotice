import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { NoticeDetailModal } from './components/NoticeDetailModal';
import { AuthModal } from './components/AuthModal';
import { AuthProvider } from './context/AuthContext';
import { HomePage } from './pages/HomePage';
import { DashboardPage } from './pages/DashboardPage';
import { NoticesPage } from './pages/NoticesPage';
import { RoutesPage } from './pages/RoutesPage';
import { AgenciesPage } from './pages/AgenciesPage';
import { HistoryPage } from './pages/HistoryPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ScraperMonitoringPage } from './pages/ScraperMonitoringPage';
import { MentorConsolePage } from './pages/MentorConsolePage';
import { SettingsPage } from './pages/SettingsPage';
import { api } from './services/api';
import { DashboardStats, TransitNotice, NotificationItem, NoticeRevision } from './types';
import { Menu, X } from 'lucide-react';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [currentPersona, setCurrentPersona] = useState<'PASSENGER' | 'OPERATIONS_MONITOR'>('PASSENGER');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentNotices, setRecentNotices] = useState<TransitNotice[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Notice Detail Modal state
  const [selectedNotice, setSelectedNotice] = useState<TransitNotice | null>(null);
  const [noticeRevisions, setNoticeRevisions] = useState<NoticeRevision[]>([]);
  const [modalOpen, setModalOpen] = useState<boolean>(false);

  // Auth Modal state
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  // Cross-page filter parameters
  const [routeFilter, setRouteFilter] = useState<string>('');
  const [searchFilter, setSearchFilter] = useState<string>('');

  // Initial Data Load
  const refreshAppData = async () => {
    try {
      const [statsData, noticesData, notifData] = await Promise.all([
        api.getStats(),
        api.getNotices({ limit: 6, sortBy: 'last_verified_at', sortOrder: 'desc' }),
        api.getNotifications({ unread_only: false })
      ]);
      setStats(statsData);
      setRecentNotices(noticesData.notices);
      setNotifications(notifData.notifications);
      setUnreadCount(notifData.unreadCount);
    } catch (err) {
      console.error('Failed to load application data:', err);
    }
  };

  useEffect(() => {
    refreshAppData();
    // Poll data every 30 seconds for live freshness in UI
    const timer = setInterval(refreshAppData, 30000);
    return () => clearInterval(timer);
  }, []);

  const handleOpenNotice = async (notice: TransitNotice) => {
    try {
      const full = await api.getNoticeById(notice.notice_id);
      setSelectedNotice(full);
      setNoticeRevisions(full.revisions || []);
      setModalOpen(true);
    } catch (err) {
      setSelectedNotice(notice);
      setNoticeRevisions([]);
      setModalOpen(true);
    }
  };

  const handleOpenNoticeById = async (noticeId: string) => {
    try {
      const full = await api.getNoticeById(noticeId);
      setSelectedNotice(full);
      setNoticeRevisions(full.revisions || []);
      setModalOpen(true);
    } catch (err) {
      console.error(err);
    }
  };

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await api.triggerScraperRefresh();
      await refreshAppData();
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleNotificationClick = (notif: NotificationItem) => {
    if (notif.notice_id) {
      handleOpenNoticeById(notif.notice_id);
    } else {
      setCurrentTab('notifications');
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
      setUnreadCount(0);
    } catch (err) {
      console.error(err);
    }
  };

  const handlePersonaChange = (persona: 'PASSENGER' | 'OPERATIONS_MONITOR') => {
    setCurrentPersona(persona);
    if (persona === 'OPERATIONS_MONITOR') {
      setCurrentTab('dashboard');
    }
  };

  const handleGlobalSearch = (query: string) => {
    setSearchFilter(query);
    setCurrentTab('notices');
  };

  const handleFilterRoute = (r: string) => {
    setRouteFilter(r);
    setCurrentTab('notices');
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-800 antialiased font-sans">
      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Desktop & Mobile Drawer Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <Sidebar
          currentTab={currentTab}
          onSelectTab={(tab) => {
            setCurrentTab(tab);
            setMobileMenuOpen(false);
          }}
          unreadAlertsCount={unreadCount}
        />
      </div>

      {/* Main Container */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Header */}
        <div className="flex items-center lg:block">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-3 text-slate-600 hover:bg-slate-100 lg:hidden border-b border-slate-200 bg-white"
            title="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>

          <div className="flex-1">
            <Header
              currentPersona={currentPersona}
              onPersonaChange={handlePersonaChange}
              onSearchSubmit={handleGlobalSearch}
              onRefreshClick={handleManualRefresh}
              isRefreshing={isRefreshing}
              notifications={notifications}
              unreadCount={unreadCount}
              onNotificationClick={handleNotificationClick}
              onMarkAllRead={handleMarkAllRead}
              onOpenAuthModal={() => setAuthModalOpen(true)}
            />
          </div>
        </div>

        {/* Page Content Viewport */}
        <main className="flex-1 px-4 sm:px-6 lg:px-8 pt-6 max-w-7xl mx-auto w-full">
          {currentTab === 'home' && (
            <HomePage
              stats={stats}
              recentNotices={recentNotices}
              onSearch={handleGlobalSearch}
              onSelectNotice={handleOpenNotice}
              onNavigateTab={setCurrentTab}
              onFilterRoute={handleFilterRoute}
            />
          )}

          {currentTab === 'dashboard' && (
            <DashboardPage
              stats={stats}
              recentNotices={recentNotices}
              onSelectNotice={handleOpenNotice}
              onNavigateTab={setCurrentTab}
            />
          )}

          {currentTab === 'notices' && (
            <NoticesPage
              initialSearch={searchFilter}
              initialRouteFilter={routeFilter}
              onSelectNotice={handleOpenNotice}
              onClearInitialRouteFilter={() => setRouteFilter('')}
            />
          )}

          {currentTab === 'routes' && (
            <RoutesPage
              onSelectRouteFilter={(r) => {
                setRouteFilter(r);
                setCurrentTab('notices');
              }}
            />
          )}

          {currentTab === 'agencies' && <AgenciesPage />}

          {currentTab === 'history' && (
            <HistoryPage onSelectNoticeId={handleOpenNoticeById} />
          )}

          {currentTab === 'notifications' && (
            <NotificationsPage onSelectNoticeId={handleOpenNoticeById} />
          )}

          {currentTab === 'scraper' && <ScraperMonitoringPage />}

          {currentTab === 'mentor' && <MentorConsolePage />}

          {currentTab === 'settings' && <SettingsPage />}
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
            <div>
              <strong className="text-slate-800">TransitNotice</strong> • Project Code: WEB-07 • Cybernaut SRS 2026
            </div>
            <div>
              Public Transport Service Update Tracker • Cloud SQL PostgreSQL & SQLite Relational Architecture
            </div>
          </div>
        </footer>
      </div>

      {/* Notice Detail Dialog */}
      <NoticeDetailModal
        notice={selectedNotice}
        revisions={noticeRevisions}
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onFilterRoute={(r) => {
          setRouteFilter(r);
          setCurrentTab('notices');
        }}
      />

      {/* User Sign-In / Registration Dialog */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
