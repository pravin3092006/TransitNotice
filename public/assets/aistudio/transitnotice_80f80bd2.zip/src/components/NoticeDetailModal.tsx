import React from 'react';
import { TransitNotice, NoticeRevision } from '../types';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  ExternalLink,
  Route,
  Shield,
  History,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Info,
  Building2,
  Copy,
  Check
} from 'lucide-react';

interface NoticeDetailModalProps {
  notice: TransitNotice | null;
  revisions: NoticeRevision[];
  isOpen: boolean;
  onClose: () => void;
  onFilterRoute?: (routeId: string) => void;
}

export const NoticeDetailModal: React.FC<NoticeDetailModalProps> = ({
  notice,
  revisions,
  isOpen,
  onClose,
  onFilterRoute
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen || !notice) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin + `/#/notices?id=${notice.notice_id}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const routes = notice.affected_routes && notice.affected_routes.length > 0
    ? notice.affected_routes
    : notice.route_id.split(',').map(r => ({ route_id: r.trim(), route_name: r.trim(), route_mode: 'BUS', direction: undefined }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-8 max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 bg-[#071B2D] px-6 py-4 text-white">
          <div className="flex-1 pr-4">
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="rounded bg-[#13BCEB] px-2 py-0.5 text-xs font-bold text-slate-950">
                {notice.agency}
              </span>
              <span className="font-mono text-xs text-slate-300">
                {notice.notice_id}
              </span>
              <span className="rounded-full bg-slate-800 px-2.5 py-0.5 text-xs font-semibold text-cyan-300 border border-slate-700">
                Status: {notice.status}
              </span>
              {notice.revision_id > 1 && (
                <span className="rounded bg-amber-400 px-2 py-0.5 text-xs font-bold text-amber-950">
                  Revision {notice.revision_id}
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold text-white leading-snug">
              {notice.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Key Advisory Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                Advisory Type
              </span>
              <span className="text-xs font-bold text-slate-800">
                {notice.type}
              </span>
              {notice.is_type_inferred === 1 && (
                <span className="block text-[10px] text-amber-700">(Inferred)</span>
              )}
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                Affected Area
              </span>
              <span className="text-xs font-bold text-slate-800 truncate block" title={notice.area}>
                {notice.area}
              </span>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                Effective Window
              </span>
              <span className="text-xs font-bold text-slate-800 block">
                {new Date(notice.valid_from).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
              <span className="text-[10px] text-slate-500">
                to {notice.valid_to ? new Date(notice.valid_to).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'Until further notice'}
              </span>
            </div>

            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-1">
                Verification Provenance
              </span>
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5" /> Verified
              </span>
              <span className="text-[10px] text-slate-500 block truncate" title={notice.last_verified_at}>
                {new Date(notice.last_verified_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          {/* Affected Routes Segment (Multi-Route Support) */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
              <Route className="h-4 w-4 text-[#13BCEB]" />
              Affected Public Transport Routes ({routes.length})
            </h4>
            <div className="flex flex-wrap gap-2">
              {routes.map((r, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs"
                >
                  <span className="font-bold text-slate-900 bg-white px-2 py-0.5 rounded shadow-2xs border border-slate-200">
                    {r.route_id}
                  </span>
                  <span className="text-slate-600 font-medium">
                    {r.route_name || `Route ${r.route_id}`}
                  </span>
                  {r.direction && (
                    <span className="text-[10px] text-slate-400 font-semibold uppercase">
                      ({r.direction})
                    </span>
                  )}
                  {onFilterRoute && (
                    <button
                      onClick={() => {
                        onClose();
                        onFilterRoute(r.route_id);
                      }}
                      className="ml-1 text-[11px] text-[#13BCEB] hover:underline"
                    >
                      Filter
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Full Announcement Description */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Official Transport Announcement
            </h4>
            <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-line bg-slate-50/70 p-4 rounded-lg border border-slate-100 font-normal">
              {notice.description}
            </p>
            {notice.summary && notice.summary !== notice.description && (
              <p className="text-xs text-slate-500 mt-2 italic">
                Summary: {notice.summary}
              </p>
            )}
          </div>

          {/* Source Provenance Timestamps & Audit Data */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <Shield className="h-4 w-4 text-emerald-600" />
              Source Provenance & Data Freshness Audit
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Official Announcement URL:</span>
                <a
                  href={notice.source_url}
                  target="_blank"
                  rel="noreferrer"
                  className="font-medium text-[#13BCEB] hover:underline flex items-center gap-1 mt-0.5 break-all"
                >
                  <span className="truncate">{notice.source_url}</span>
                  <ExternalLink className="h-3 w-3 shrink-0" />
                </a>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Content Integrity Hash (SHA-256):</span>
                <span className="font-mono text-[11px] text-slate-600 truncate block mt-0.5" title={notice.content_hash}>
                  {notice.content_hash}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Published Date:</span>
                <span className="font-medium text-slate-700 mt-0.5 block">
                  {new Date(notice.published_at).toLocaleString()}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Last Observed by Scraper:</span>
                <span className="font-medium text-slate-700 mt-0.5 block">
                  {new Date(notice.observed_at).toLocaleString()}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Last Confirmed in Feed:</span>
                <span className="font-medium text-slate-700 mt-0.5 block">
                  {new Date(notice.last_confirmed_at).toLocaleString()}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Last Verified Active:</span>
                <span className="font-medium text-slate-700 mt-0.5 block text-emerald-700">
                  {new Date(notice.last_verified_at).toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Immutable Revision History Timeline */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-3">
              <History className="h-4 w-4 text-indigo-600" />
              Notice Revision History ({revisions.length} recorded version{revisions.length > 1 ? 's' : ''})
            </h4>

            {revisions.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">No historical revisions recorded yet.</p>
            ) : (
              <div className="relative border-l-2 border-slate-200 pl-4 ml-2 space-y-4">
                {revisions.map((rev) => (
                  <div key={rev.id} className="relative">
                    {/* Circle icon */}
                    <div className="absolute -left-[23px] top-1 h-3.5 w-3.5 rounded-full border-2 border-white bg-[#13BCEB] shadow-2xs" />

                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">
                          Revision {rev.revision_id}
                        </span>
                        <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                          rev.change_type === 'NEW' ? 'bg-blue-100 text-blue-800' :
                          rev.change_type === 'EXTENDED' ? 'bg-amber-100 text-amber-800' :
                          rev.change_type === 'CANCELLED' ? 'bg-red-100 text-red-800' :
                          'bg-purple-100 text-purple-800'
                        }`}>
                          {rev.change_type}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          Status: {rev.status}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400">
                        {new Date(rev.detected_at).toLocaleString()}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-slate-800 mt-1">
                      {rev.title}
                    </p>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {rev.change_summary}
                    </p>
                    <div className="text-[10px] text-slate-400 mt-1">
                      Validity: {new Date(rev.valid_from).toLocaleDateString()} to {rev.valid_to ? new Date(rev.valid_to).toLocaleDateString() : 'Indefinite'}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-6 py-3">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 transition"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5 text-slate-500" />}
            <span>{copied ? 'Link Copied!' : 'Copy Share Link'}</span>
          </button>

          <div className="flex items-center gap-2">
            <a
              href={notice.source_url}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 rounded-lg bg-[#071B2D] px-4 py-1.5 text-xs font-medium text-white hover:bg-slate-800 transition shadow-xs"
            >
              <span>View Official Source</span>
              <ExternalLink className="h-3.5 w-3.5 text-[#13BCEB]" />
            </a>
            <button
              onClick={onClose}
              className="rounded-lg border border-slate-300 bg-white px-4 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
