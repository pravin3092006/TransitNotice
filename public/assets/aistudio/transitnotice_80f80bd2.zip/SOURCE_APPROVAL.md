# Official Source Approval Document (Cybernaut WEB-07)

This document formalizes the ethical, legal, and operational assessment of monitored transport authorities.

## 1. Ethical Web Scraping Policy
TransitNotice strictly complies with ethical data collection standards:
- **Zero Authentication Bypass**: Never bypass user logins, tokens, paywalls, or private intranet feeds.
- **Zero CAPTCHA Evasion**: No OCR, third-party solving services, or automated anti-bot avoidance.
- **Data Minimization**: No private passenger identifiers or contact details are scraped or recorded.
- **Respect for Server Load**: Polite request throttling, caching, exponential backoff (up to 300s), and custom User-Agent headers identifying the application administrator.

---

## 2. Monitored Authorities Matrix

| Agency | Authority Name | Endpoint URL | Source Type | Permission Status | robots.txt Status | Terms / License Review | Refresh Frequency |
|---|---|---|---|---|---|---|---|
| **TFL** | Transport for London | `https://api.tfl.gov.uk/Line/Mode/tube,bus,overground,dlr/Disruption` | REST API (JSON) | Approved | Allowed | UK Open Government Licence (OGL) v3.0 / TfL Open Data | 15 mins |
| **BART** | Bay Area Rapid Transit | `https://api.bart.gov/api/bsa.aspx?cmd=bsa&json=y` | REST API (JSON) | Approved | Allowed | BART Developer License Agreement (Open Permitted) | 10 mins |
| **MBTA** | Massachusetts Bay Transportation Authority | `https://api-v3.mbta.com/alerts?filter[activity]=BOARD,EXIT,RIDE` | REST API (JSON:API) | Approved | Allowed | MassDOT / MBTA Open Data Policy | 20 mins |
| **CTA** | Chicago Transit Authority | `https://www.transitchicago.com/alerts/rss.aspx` | RSS / XML Feed | Approved | Allowed | CTA Terms of Website Use (Public RSS syndication) | 30 mins |

---

## 3. Extracted Fields Dictionary
- `notice_id`: Stable identifier supplied by source or derived deterministically.
- `agency`: Authority acronym (TFL, BART, MBTA, CTA).
- `route_id`: Primary route code or comma-separated route list.
- `area`: Affected borough, city district, or line segment.
- `source_url`: Verifiable provenance hyperlink to official bulletin.
- `type`: Standardized advisory classification (Route Diversion, Service Interruption, Planned Maintenance, Delay, Route Closure, Service Cancellation, Service Resumption, General Advisory).
- `title`: Short descriptive headline.
- `summary`: Concise passenger guidance.
- `description`: Complete announcement text.
- `published_at`: Announcement issuance timestamp in ISO-8601 UTC.
- `valid_from`: Beginning of effective outage window.
- `valid_to`: Scheduled restoration timestamp, or NULL if open-ended.
- `status`: Active, Scheduled, Expired, Cancelled, Withdrawn, Unknown.
- `observed_at`: Scraper detection timestamp.
- `last_confirmed_at`: Most recent cycle where source confirmed presence.
- `last_verified_at`: Timestamp of active validity verification.
- `content_hash`: SHA-256 hash of normalized content.
- `revision_id`: Monotonically increasing revision counter (starts at 1).
- `change_summary`: Human-readable audit diff message.
