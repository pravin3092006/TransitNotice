@echo off
echo ========================================================
echo   Starting TransitNotice Full-Stack Monitoring Server
echo ========================================================
echo.
echo Launching Express + Vite + SQLite + Scraper Scheduler on http://localhost:3000...
echo.

start "" "http://localhost:3000"
npm run dev
pause
