@echo off
echo Stopping TransitNotice processes...
taskkill /F /IM node.exe /T 2>nul
taskkill /F /IM python.exe /T 2>nul
echo All TransitNotice background processes stopped.
pause
