@echo off
echo ========================================================
echo   Running TransitNotice Automated Test Suite (24 Cases)
echo ========================================================
echo.

if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
)

python -m pytest backend\tests\test_transitnotice.py -v
if %errorlevel% equ 0 (
    echo.
    echo [SUCCESS] All 24 automated tests passed successfully!
) else (
    echo.
    echo [ERROR] Some tests failed. Review output above.
)
pause
