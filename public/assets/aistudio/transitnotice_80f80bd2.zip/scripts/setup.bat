@echo off
echo ========================================================
echo   TransitNotice (WEB-07) - Environment Setup Script
echo ========================================================
echo.

echo [1/4] Checking prerequisites (Node.js and Python)...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH. Please install Node.js 18+ from https://nodejs.org/
    pause
    exit /b 1
)

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH. Please install Python 3.10+ from https://python.org/
    pause
    exit /b 1
)

echo [2/4] Installing Node.js frontend and server dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install npm dependencies.
    pause
    exit /b 1
)

echo [3/4] Setting up Python virtual environment...
if not exist "venv" (
    python -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r backend\requirements.txt
if %errorlevel% neq 0 (
    echo [WARNING] Some python requirements could not be installed. Standard stdlib fallback will be used.
)

echo [4/4] Verifying SQLite database initialization and building frontend...
call npm run build

echo.
echo ========================================================
echo   Setup Complete! Run scripts\start.bat to start TransitNotice.
echo ========================================================
pause
